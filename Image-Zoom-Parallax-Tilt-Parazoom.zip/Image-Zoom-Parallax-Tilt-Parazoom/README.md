# Parazoom

A jQuery plugin that adds cool mouse hover features on images.
